
<h1 align="centre"> 🇸🇴Somalibots⚡</h1>

### 𝚙𝚛𝚘𝚓𝚎𝚌𝚝 𝚖𝚞𝚜𝚒𝚌 𝚋𝚘𝚝 𝚔𝚊𝚗 𝚠𝚊𝚡𝚊𝚊 𝚕𝚎𝚑 𝚂𝚘𝚖𝚊𝚕𝚒𝚋𝚘𝚝𝚜 ©

<p align="center"><a href="https://t.me/Somalibots"><img src="https://telegra.ph/file/8dc2346939ef1184fcf01.jpg" width="400"></a></p>
<p align="center">
    <a href="https://www.python.org/" alt="Waxan_
    ku sameeynay-python"> <img src="https://img.shields.io/badge/Waxaan ku sameeynay%20with-Python-Red.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>

<h2>ʙᴏᴏs ᴀϙʀɪ📰</h2>

- Somalibots
- Developer [⚡ATTACK 📌](https://t.me/AttackTor)
- Waxan ku sameeynay Python 3.8+ or 3.7
- Somalibots backup [Projects](https://github.com/Yaamiin/)
- [MongoDB](https://cloud.mongodb.com/)

[![ɢᴇɴᴇʀᴀᴛᴇ ꜱᴇꜱꜱɪᴏɴ](https://img.shields.io/badge/repl.it-generateString-Blue)](https://replit.com/@Yaamiin/somalibots#main.py)


👋 ɢᴇᴛ STRING_SESSION ꜰʀᴏᴍ ʜᴇʀᴇ:

[@genStr_Bot](https://t.me/genStr_Bot)

### ᴄᴏᴍᴍᴀɴᴅꜱ created by Zaid -Big Thanks 😊

[TAABO💚](https://t.me/Somalibots)


## ꜰᴇᴀᴛᴜʀᴇꜱ ᴡɪᴛʜ ᴀɪ 🔥️

- **ᴘʟᴀʏ ᴍᴜꜱɪᴄ ɪɴ ᴛᴇʟᴇɢʀᴀᴍ ɢʀᴏᴜᴘ ᴠᴏɪᴄᴇ ᴄʜᴀᴛꜱ!** (ꜱᴜᴘᴘᴏʀᴛꜱ ᴍᴜʟᴛɪᴘʟᴇ ɢʀᴏᴜᴘꜱ)
- **ꜱᴜᴘᴘᴏʀᴛꜱ Qᴜᴇᴜᴇꜱ!**
- **ᴄᴏɴᴛʀᴏʟ ʙʏ ʙᴜᴛᴛᴏɴꜱ ᴏʀ ᴄᴏᴍᴍᴀɴᴅꜱ**
- **ꜱᴇᴀʀᴄʜ ꜰᴏʀ ʏᴏᴜᴛᴜʙᴇ ᴠɪᴅᴇᴏꜱ ɪɴʟɪɴᴇ!**
- **ᴅᴏᴡɴʟᴏᴀᴅ ʏᴛ ꜱᴏɴɢꜱ ʙʏ ɪᴛ'ꜱ ɴᴀᴍᴇ!**
- **ᴅᴏᴡɴʟᴏᴀᴅ ʏᴛ ᴠɪᴅᴇᴏꜱ ʙʏ ɪᴛ'ꜱ ɴᴀᴍᴇ!**
- **ᴀꜱꜱɪꜱᴛᴀɴᴛ ʟɪᴋᴇ ᴜꜱᴇʀʙᴏᴛ**
- **ɢᴇᴛ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ʟɪɴᴋ!** (ᴘᴜʙʟɪᴄ ɢʀᴏᴜᴘꜱ ᴏɴʟʏ )
- **ɢᴇᴛ ʟʏʀɪᴄꜱ ᴏꜰ ʏᴏᴜʀ ꜱᴏɴɢ!**
- **ᴊᴏɪɴ & ʟᴇᴀᴠᴇ ꜱᴛʀᴇᴀᴍᴇʀ ᴀᴄᴄᴏᴜɴᴛ ᴜꜱɪɴɢ ᴀ ᴄᴏᴍᴍᴀɴᴅ**
- **ʙᴀɴ / ᴜɴʙᴀɴ ᴜꜱᴇʀꜱ ᴀɴᴅ ᴄʜᴇᴄᴋ ᴜꜱᴇʀ ꜱᴛᴀᴛᴜꜱ.**
- **ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴍᴇꜱꜱᴀɢᴇꜱ**
- **ᴀɪ**
- **ᴄᴏᴏʟ ꜱᴛᴀʀᴛꜱ ᴘʟᴜɴɢɪɴꜱ**
- **ᴜᴘᴅᴀᴛᴇ ʏᴏᴜʀ ʙᴏᴛ ᴇᴀꜱɪʟʏ**

## 🔎 ꜱᴜᴘᴘᴏʀᴛ ɪɴʟɪɴᴇ ꜱᴇᴀʀᴄʜ

## ʜᴇʀᴏᴋᴜ ᴅᴇᴘʟᴏʏᴍᴇɴᴛꜱ 🔥
ʜᴇʀᴏᴋᴜ ɪꜱ ᴛʜᴇ ᴇᴀꜱʏ ᴡᴀʏ ᴛᴏ ʜᴏꜱᴛ ᴜʀ ᴀᴘᴘꜱ

[![𝚂𝚘𝚖𝚊𝚕𝚒𝚋𝚘𝚝𝚜 ᴅᴇᴘʟᴏʏ](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Itsunknown-12/Zaid-Vc-Player)

## ᴜᴘᴅᴀᴛᴇs ᴋɪɪɴᴀ xᴀɢᴇᴇɴ ᴋᴀ ʜᴇʟᴀᴀ?!
𝚄𝚙𝚍𝚊𝚝𝚎𝚜 𝙺𝚎𝚎𝚗𝚊 𝚆𝚊𝚡𝚊𝚗 𝚂𝚘 𝚍𝚑𝚒𝚐𝚗𝚊𝚊 𝙷𝚊𝚕𝚔𝚊𝚗!  [Somalibots](https://t.me/Somalibots), 𝙨𝙤𝙤 gal.

### ꜱᴘᴇᴄɪᴀʟ ᴄʀᴇᴀᴅɪᴛꜱ 👏💚
- Zaid
- Callsmusic
- Yukki
- Daisy
- PyroGram
- xyz 

